
---------------
-- Interface --
---------------

gbfs = {}

------------
-- Consts --
------------

gbfs.maxstacklevel    = 100
gbfs.debug            = true

-------------
-- Globals --
-------------

gbfs.stack        = {}
gbfs.stackstring  = ""
gbfs.stacklevel   = 0

---------------
-- Functions --
---------------

gbfs.char = function(s,n)
  return string.char(string.byte(s,n))
end

gbfs.tokenize = function(s,t)
  t         = t or "/"
  local r   = {}
  local ri  = 0
  local w   = ""
  local c   = ""
  
  local l = string.len(s)
  if (l > 0) then
    local i = 1
    while i <= l do
    
      c = gbfs.char(s,i)
      if (c == t) then
        if (string.len(w) > 0) then
          ri = ri + 1
          r[ri] = w
          w = ""
        end
      else
        w = w .. c
      end
    
      i = i + 1
    end
    
    if (string.len(w) > 0) then
      ri = ri + 1
      r[ri] = w
    end
  end
  return r
end

gbfs.updatestackstring = function()
  gbfs.stackstring = ""
  if (gbfs.stacklevel > 0) then
    local i = 1
    while i <= gbfs.stacklevel do
      gbfs.stackstring = gbfs.stackstring .. gbfs.stack[i] .. "/"
      i = i + 1
    end
  end
end

gbfs.push = function(t)
  t = gbfs.tokenize(t)
  local l = #t
  local i = 1
  while i <= l do
    if (gbfs.stacklevel < gbfs.maxstacklevel) then
      gbfs.stacklevel = gbfs.stacklevel + 1
      gbfs.stack[ gbfs.stacklevel ] = t[i]
      gbfs.updatestackstring()
    end
    i = i + 1
  end
  
  if (gbfs.debug) then
    print("GBFS: " .. gbfs.stackstring)
  end
  
  return gbfs.stacklevel
end

gbfs.pop = function(n)
  n = n or 1
  while n > 0 do
    if gbfs.stacklevel > 0 then
      gbfs.stack[ gbfs.stacklevel ] = nil
      gbfs.stacklevel = gbfs.stacklevel - 1
      gbfs.updatestackstring()
    end
    n = n - 1
  end
  
  if (gbfs.debug) then
    print("GBFS: " .. gbfs.stackstring)
  end
  
  return gbfs.stacklevel
end

gbfs.include = function(t)

  local u = gbfs.stackstring .. t

  if (gbfs.debug) then
    print("GBFS: " .. u)
  end

  require(u)
end

gbfs.flush = function()
  gbfs.stacklevel     = 0
  gbfs.stackstring    = ""
  gbfs.stack          = {}
end
