
-- GBFS framework
require ("gbfs/gbfs")

-- GB framework
gbfs.push("gb")
  gbfs.include("gb")
gbfs.pop()

-- pipes framework
gbfs.push("pipes")
  gbfs.include("pipes")
gbfs.pop()

------------
-- events --
------------

love.load = function()
  app = gb.app.new()
  gb.app.init(app)
end

love.update = function(d)
end

love.draw = function()
end

love.quit = function()
end

love.keypressed = function(k)
end

love.keyreleased = function(k)
end


----------
-- main --
----------

