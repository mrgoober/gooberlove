
---------------
-- interface --
---------------

gb.visual = {}

----------------
-- allocation --
----------------

gb.visual.new = function()
  local r       = {}
  r.pixels      = gb.point.new(400,240)
  r.size        = gb.point.new(1200,720)
  r.scale       = 3
  r.fullscreen  = false
  r.title       = "Untitled Window"
  
  r.pixelratio  = r.pixels.x / r.pixels.y
  r.sizeratio   = r.size.x   / r.size.y
  
  return r
end

---------------
-- functions --
---------------

gb.visual.setscale = function(v,s)
  v.size.x    = v.pixels.x * v.scale
  v.size.y    = v.pixels.y * v.scale
end

gb.visual.setsize = function(v,x,y)
  v.size.x  = x
  v.size.y  = y
  v.scale   = v.size.x / v.pixels.x
end

gb.visual.setpixels = function(v,x,y)
  v.pixels.x  = x
  v.pixels.y  = y
  v.size.x    = v.pixels.x * v.scale
  v.size.y    = v.pixels.y * v.scale
end

gb.visual.settitle = function(v,t)
  v.title = t
end

--  The refresh function should be called when the window is ready to be
--  updated. You can make several changes to the visual object before pushing
--  the update to love2d.
gb.visual.refresh = function(v)
  love.window.setMode(v.size.x, v.size.y, {
    fullscreen  = v.fullscreen,
    minwidth    = v.pixels.x,
    minheight   = v.pixels.y
  })
  love.window.setTitle(v.title)
end
