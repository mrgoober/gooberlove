

---------------
-- Functions --
-------------------------------------------------------------------------------

gb.min = function(n,l)
  if (n<l) then return l
  else return n
  end
end

gb.max = function(n,h)
  if (n>h) then return h
  else return n
  end
end

gb.clamp = function(n,l,h)
  return gb.min(gb.max(n,h),l)
end

gb.wrap = function(n,l,h)
  local o = (h-l)
  while (n <  l) do n = n + (o) end
  while (n >= h) do n = n - (o) end
  return n
end

gb.char = function(s,n)
  return string.char(string.byte(s,n))
end

gb.asc = string.byte

gb.tokenize = function(s,t)
  t         = t or "/"
  local r   = {}
  local ri  = 0
  local w   = ""
  local c   = ""
  
  local l = string.len(s)
  if (l > 0) then
    local i = 1
    while i <= l do
    
      c = gb.char(s,i)
      if (c == t) then
        if (string.len(w) > 0) then
          ri = ri + 1
          r[ri] = w
          w = ""
        end
      else
        w = w .. c
      end
    
      i = i + 1
    end
    
    if (string.len(w) > 0) then
      ri = ri + 1
      r[ri] = w
    end
  end
  return r
end

gb.rand = math.random

-------------
-- Objects --
-------------------------------------------------------------------------------

gb.object = function(cl)
  local r   = {}
  r.class   = {"object"}
  if (cl ~= nil) then
    gb.push(r.class, tostring(cl))
  end
  return r
end

gb.copy = function(a)
  local r = {}
  local q = 0
  for i,j in pairs(a) do
    q = type(j)
    if (q == "table") then
      r[i] = gb.copy(a[i])
    else
      r[i] = a[i]
    end
  end
  return r
end

gb.merge = function(a,b)
  for i,j in pairs(b) do
    a[i] = b[i]
  end
end

-------------
-- Control --
-------------------------------------------------------------------------------

gb.switch = function()
  local r = gb.object("switch")
  r.cases = {}
  return r
end

gb.case = function(s,n,f)
  s.cases[n] = f
end

gb.select = function(s,n)
  if (type(s.cases[n]) == "function") then
    return s.cases[n]()
  end
end

--------------------
-- List Functions --
-------------------------------------------------------------------------------

gb.push = function(l,d)
  l[#l+1] = d
end

gb.pop = function(l)
  local d = nil
  if (#l > 0) then
    d = l[#l]
    l[#l] = nil
  end
  return d
end

gb.pushfirst = function(l,d)
  table.insert(t,1,d)
end

gb.popfirst = function(l)
  local d = nil
  if (#l > 0) then
    d = l[1]
    table.remove(l,1)
  end
  return d
end

gb.pushlast   = gb.push
gb.poplast    = gb.pop

gb.first = function(l)
  return l[1]
end

gb.last = function(l)
  return l[#l]
end

-------------------------------------------------------------------------------

gb.find = function(o,f)
  for i,j in pairs(o) do
    if (j == f) then
      return i
    end
  end
  return gb.null
end

gb.ifind = function(o,f)
  for i,j in ipairs(o) do
    if (j == f) then
      return i
    end
  end
  return gb.null
end

-----------
-- Range --
-------------------------------------------------------------------------------

gb.inrange = function(n,l,h)
  if (n >= l) and (n < h) then
    return true
  end
  return false
end

gb.pointinrect = function(x1,y1,x2,y2,w,h)
  if (x1 >= x2) and (x1 < x2+w) and (y1 >= y2) and (y1 < y2+h) then
    return true
  end
  return false
end

gb.rectinrect = function(x1,y1,w1,h1,x2,y2,w2,h2)
  if
    gb.pointinrect(x1,   y1,   x2,y2,w2,h2) or 
    gb.pointinrect(x1+w1,y1,   x2,y2,w2,h2) or
    gb.pointinrect(x1,   y1+h1,x2,y2,w2,h2) or
    gb.pointinrect(x1+w1,y1+h1,x2,y2,w2,h2) or
    
    gb.pointinrect(x2,   y2,   x1,y1,w1,h1) or 
    gb.pointinrect(x2+w2,y2,   x1,y1,w1,h1) or
    gb.pointinrect(x2,   y2+h2,x1,y1,w1,h1) or
    gb.pointinrect(x2+w2,y2+h2,x1,y1,w1,h1)
  then
    return true
  end
  return false
end

----------
-- trig --
-------------------------------------------------------------------------------

gb.angle = function(a)
  a = gb.wrap(a,0,1000)
  return (math.pi*2) * (a/1000)
end

gb.sin = function(n)
  return math.sin(gb.angle(n))
end

gb.cos = function(n)
  return math.cos(gb.angle(n))
end
