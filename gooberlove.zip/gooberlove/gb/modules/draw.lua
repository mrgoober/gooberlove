
---------------
-- interface --
---------------

gb.draw = {}

----------------
-- allocation --
----------------

gb.draw.new = function()
  local r = {}
  
  r.pos     = gb.point.new(0,0)
  r.scale   = gb.point.new(1,1)
  
  r.imglist = nil
  
  return r
end

---------------
-- functions --
---------------

-- general --

-- The img list is an allocator. Set the draw object's imglist to an allocator.
-- The draw object will not know which image to use if this is null. 
gb.draw.setimglist = function(d,l)
  d.imglist = l
end

-- drawing --

-- d      : draw object
-- x/y    : draw offsets
-- im     : index in imglist
-- ix/iy  : image tile offsets
gb.draw.tile = function(d,x,y,im,ix,iy)
  if (d.imglist) then
    
    local m = gb.allocator.get(d.imglist,im)
    
    gb.image.setquad    (m.quad,ix*10,iy*10,10,10)
    love.graphics.draw  ((x*d.scale.x) + d.pos.x, (y*d.scale.y) + d.pos.y,
      m.source, m.quad,
      0, d.scale.x, d.scale.y)
  end
end

gb.draw.tilerect = function(d,x,y,im,ix,iy,w,h)
end

gb.draw.tilebox = function(d,x,y,im,ix,iy,iw,ih)
end

gb.draw.text = function(d,x,y,t,f)
end
