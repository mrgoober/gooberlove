
--------------------------
-- 1-Dimensional Arrays --
--------------------------

gb.array = function(l,v)
  local r = {}
  for i=1,l do
    r[i] = v
  end
  return r
end

gb.aset = function(a,n,v)
  a[n] = v
end

gb.aget = function(a,n)
  return a[n]
end

gb.aadd = function(a,n,v)
  a[n] = a[n] + v
end

gb.amul = function(a,n,v)
  a[n] = a[n] * v
end

gb.adiv = function(a,n,v)
  a[n] = a[n] / v
end

--------------------------
-- 2-Dimensional Arrays --
--------------------------

gb.array2d = function(x,y,v)
  local r = {}
  for i=1,x do
    r[i] = {}
    for j=1,y do
      r[i][j] = v
    end
  end
  return r
end

gb.a2set = function(a,x,y,v)
  a[x][y] = v
end

gb.a2get = function(a,x,y)
  return a[x][y]
end

gb.a2add = function(a,x,y,v)
  a[x][y] = a[x][y] + v
end

gb.a2mul = function(a,x,y,v)
  a[x][y] = a[x][y] * v
end

gb.a2div = function(a,x,y,v)
  a[x][y] = a[x][y] / v
end

--------------------------
-- 3-Dimensional Arrays --
--------------------------

gb.array3d = function(x,y,z,v)
  local r = {}
  for i=1,x do
    r[i] = {}
    for j=1,y do
      r[i][j] = {}
      for k=1,z do
        r[i][j][k] = v
      end
    end
  end
  return r
end

gb.a3set = function(a,x,y,z,v)
  a[x][y][z] = v
end

gb.a3get = function(a,x,y,z)
  return a[x][y][z]
end

gb.a3add = function(a,x,y,z,v)
  a[x][y][z] = a[x][y][z] + v
end

gb.a3mul = function(a,x,y,z,v)
  a[x][y][z] = a[x][y][z] * v
end

gb.a3div = function(a,x,y,z,v)
  a[x][y][z] = a[x][y][z] / v
end
