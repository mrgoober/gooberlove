
---------------
-- interface --
---------------

gb.point = {}

----------------
-- allocation --
----------------

gb.point.new = function(x,y)
  local r = {}
  r.x = x
  r.y = y
  return r
end

gb.point.set = function(p,x,y)
  p.x = x
  p.y = y
end

gb.point.get = function(p)
  return x,y
end

gb.point.add = function(p,x,y)
  p.x = p.x + x
  p.y = p.y + y
end

gb.point.mul = function(p,x,y)
  p.x = p.x * x
  p.y = p.y * y
end

gb.point.div = function(p,x,y)
  p.x = p.x / x
  p.y = p.y / y
end

-------------
-- aliases --
-------------

gb.pset = gb.point.set
gb.pget = gb.point.get
gb.padd = gb.point.add
gb.pmul = gb.point.mul
gb.pdiv = gb.point.div
