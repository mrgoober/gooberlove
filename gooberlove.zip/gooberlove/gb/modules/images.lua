
---------------
-- interface --
---------------

gb.image = {}

----------------
-- allocation --
----------------

gb.image.new = function(f,x,y)
  x = x or 400
  y = y or 240
  local r   = {}
  r.size    = gb.point.new(x,y)
  r.source  = love.graphics.newImage(f)
  r.quad    = love.graphics.newQuad(0, 0, x, y, x, y)
  return r
end

---------------
-- functions --
---------------

gb.image.setquad = function(i,x,y,w,h)
  i.quad:setViewport(x,y,w,h)
end

gb.image.size = function(i)
  return i.size
end

gb.image.source = function(i)
  return i.source
end

gb.image.quad = function(i)
  return i.quad
end
