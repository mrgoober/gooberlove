
---------------
-- interface --
---------------

gb.font = {}

----------------
-- allocation --
----------------

gb.font.new = function()
  local r = {}
  
  r.image = nil
  r.pos   = gb.point.new(1,1)
  r.size  = gb.point.new(10,10)
  
  return r
end

---------------
-- functions --
---------------

gb.font.setpos = function(f,x,y)
  gb.point.set(f.pos,x,y)
end

gb.font.setsize = function(f,x,y)
  gb.point.set(f.size,x,y)
end

gb.font.setimage = function(f,i)
  f.image = i
end
