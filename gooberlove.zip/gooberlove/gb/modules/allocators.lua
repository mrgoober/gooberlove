
---------------
-- interface --
---------------

gb.allocator = {}

----------------
-- allocation --
----------------

gb.allocator.new = function(f)
  local r = {}
  r.instpos   = 0
  r.count     = 0
  r.data      = {}
  r.newfunc   = f
  return r
end
---------------
-- functions --
---------------

gb.allocator.setnew = function(a,f)
  a.newfunc = f
end

gb.allocator.alloc = function(a,n,...)
  if (a.data[n] == nil) then
    a.count = a.count + 1
  end
  a.data[n] = a.newfunc(...)
  return a.data[n]
end

gb.allocator.inst = function(a,...)
  if (a.newfunc) then
    while (a.data[a.instpos] ~= nil) do
      a.instpos           = a.instpos + 1
    end
    a.count             = a.count + 1
    a.data[a.instpos]   = a.newfunc(...)
    return a.instpos
  end
  return gb.undefined
end

gb.allocator.get = function(a,n)
  return a.data[n]
end
