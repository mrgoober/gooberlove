
---------------
-- interface --
---------------

gb.controller = {}

-------------
-- globals --
-------------

gb.controller.maxbuttons = 16

----------------
-- allocation --
----------------

gb.controller.new = function()
  local r = {}
  
  r.buttons   = gb.array    (gb.controller.maxbuttons,0)
  r.keymaps   = gb.array2d  (gb.controller.maxbuttons,2,0)
  
  gb.controller.setdefaultmaps(r)
  
  return r
end

---------------
-- functions --
---------------

gb.controller.setdefaultmaps = function(c)
  c.keymaps[1][1] = "up"
  c.keymaps[2][1] = "right"
  c.keymaps[3][1] = "down"
  c.keymaps[4][1] = "left"
  c.keymaps[5][1] = "z"
  c.keymaps[6][1] = "x"
  c.keymaps[7][1] = "c"
  c.keymaps[8][1] = "v"
  c.keymaps[9][1] = "enter"
  c.keymaps[10][1] = "space"
  c.keymaps[11][1] = "escape"
  c.keymaps[12][1] = "lshift"
  c.keymaps[12][2] = "rshift"
  c.keymaps[13][1] = "f1"
  c.keymaps[14][1] = "f2"
  c.keymaps[15][1] = "f3"
  c.keymaps[16][1] = "f4"
end

gb.controller.down = function(c,n)
  c.buttons[n] = 2
end

gb.controller.up = function(c,n)
  c.buttons[n] = 0
end

gb.controller.getbutton = function(c,n)
  return c.buttons[n]
end

------------
-- events --
------------

gb.controller.update = function(c)
  for i=1,gb.controller.maxbuttons do
    if (c.buttons[i] == 2) then
      c.buttons[i] = 1
    end
  end
end
