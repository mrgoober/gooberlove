
---------------
-- interface --
---------------

gb.entity = {}

----------------
-- allocation --
----------------

gb.entity.new = function()
  local r = {}
  r.pos   = gb.point.new(0,0)
  r.size  = gb.point.new(1,1)
  return r
end

---------------
-- functions --
---------------

gb.entity.setpos = function(e,x,y)
  e.pos.x = x
  e.pos.y = y
end

gb.entity.setsize = function(e,w,h)
  e.size.x = x
  e.size.y = y
end

gb.entity.colliding = function(e1,e2)
  return gb.rectinrect(e1.pos.x, e1.pos.y, e1.size.x, e1.size.y,
    e2.pos.x, e2.pos.y, e2.size.x, e2.size.y)
end

--  Slide in a cardinal direction
--  1: north, 2: east, 3: south, 4: west
--  checks against list of entities l
gb.entity.slide = function(e,d,a,l)
  d = d or 1
end

gb.entity.move = function(e,x,y,l)
end
