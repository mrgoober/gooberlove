
-------------
-- globals --
-------------

gb.undefined = -1
