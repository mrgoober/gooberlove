
---------------
-- interface --
---------------

gb.app = {}

----------------
-- allocation --
----------------

gb.app.new = function()
  local r = {}
  
  r.visuals     = gb.visual.new()
  r.images      = gb.allocator.new(gb.image.new)
  r.fonts       = gb.allocator.new(gb.font.new)
  r.draw        = gb.draw.new()
  r.controller  = gb.controller.new()
  
  return r
end

------------
-- events --
------------

gb.app.init = function(a)
  gb.allocator.alloc(a.images,1,"gb/media/images/1.png")
  gb.visual.refresh(a.visuals)
  
  local u = gb.allocator.alloc(a.fonts,1)
  gb.font.setimage  (u,gb.allocator.get(a.images,1))
  gb.font.setpos    (u,1,1)
  gb.font.setsize   (u,10,10)
  
end

gb.app.update = function(a,d)
  gb.controller.update(a.controller)
end

gb.app.keydown = function(a,k)
  gb.controller.keydown(a.controller,k)
end

gb.app.keyup = function(a,k)
  gb.controller.keyup(a.controller,k)
end
