
---------------
-- interface --
---------------

gb.list = {}

-------------
-- globals --
-------------

gb.list.first = function(l)
  return l.first 
end

gb.list.last = function(l)
  return l.last
end

gb.list.count = function(l)
  return l.count
end


----------------
-- allocation --
----------------

gb.list.new = function()
  local r     = {}
  r.count     = 0
  r.first     = gb.undefined
  r.last      = gb.undefined
  return r
end

---------------
-- functions --
---------------

-- List Nodes

gb.list.node = {}

gb.list.node.new = function(d)
  local r   = {}
  r.data    = d
  r.next    = gb.undefined
  r.prev    = gb.undefined
  return r
end

gb.list.node.setprev = function(n,d)
  n.prev = d
end

gb.list.node.setnext = function(n,d)
  n.next = d
end

gb.list.node.setdata = function(n,d)
  n.data = d
end

-- -- -- -- --

gb.list.addfirst = function(l,d)
  local u = gb.list.node.new(d)
  
  if (l.count == 0) then
    l.first       = u
    l.last        = u
    l.count       = 1
  else
    u.next        = l.first
    l.first.prev  = u
    l.first       = u
    l.count       = l.count + 1
  end

end

gb.list.addlast = function(l,d)

  local u = gb.list.node.new(d)
  
  if (l.count == 0) then
    l.first       = u
    l.last        = u
    l.count       = 1
  else
    u.prev        = l.last
    l.last.next   = u
    l.last        = u
    l.count       = l.count + 1
  end

end

gb.list.removefirst = function(l)
  if (l.count == 1) then
    l.first     = nil
    l.last      = nil
    l.count     = 0
  
  elseif (l.count == 2) then
    l.first         = l.last
    l.first.prev    = nil
    l.count         = 1
    
  elseif (l.count > 2) then
    l.first       = l.first.next
    l.first.prev  = nil
    l.count       = l.count - 1
  end
end

gb.list.removelast = function(l)
  if (l.count == 1) then
    l.first     = nil
    l.last      = nil
    l.count     = 0
  
  elseif (l.count == 2) then
    l.last      = l.first
    l.last.next = nil
    l.count     = 1
    
  elseif (l.count > 2) then
    l.last        = l.last.prev
    l.last.next   = nil
    l.count = l.count - 1
  end
end

gb.list.getfirst = function(l)
  if (l.first ~= nil) then
    return l.first.data
  end
end

gb.list.getlast = function(l)
  if (l.last ~= nil) then
    return l.last.data
  end
end

gb.list.tostring = function(l)
  local t = "{"

  if (l.count == 1) then
    return t .. l.first.data .. "}"
  elseif (l.count > 1) then
    local d = l.first
    for i=1,l.count do
      if (i == 1) then
        t = t .. l.first.data .. ","
      elseif (i == l.count) then
        t = t .. l.last.data
      else
        t = t .. d.data .. ","
      end
      d = d.next
    end
  end
  
  t = t .. "}"
  
  return t
end
