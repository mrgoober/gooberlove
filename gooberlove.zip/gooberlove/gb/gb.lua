
---------------
-- interface --
---------------

gb = {}

--------------
-- includes --
--------------

gbfs.push("modules")
  gbfs.include("globals")
  gbfs.include("functions")
  gbfs.include("arrays")
  gbfs.include("lists")
  gbfs.include("points")
  gbfs.include("controllers")
  gbfs.include("entities")
  gbfs.include("visuals")
  gbfs.include("allocators")
  gbfs.include("images")
  gbfs.include("fonts")
  gbfs.include("draw")
  gbfs.include("apps")
gbfs.pop()
