
---------------
-- interface --
---------------

pipes.draw = {}

----------------
-- allocation --
----------------

pipes.draw.new = function()
  local r = {}
  
  return r
end

---------------
-- functions --
---------------

pipes.draw.board = function(b,a)
  
end


