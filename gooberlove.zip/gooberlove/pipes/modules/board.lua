
---------------
-- interface --
---------------

pipes.board = {}

----------------
-- allocation --
----------------

pipes.board.new = function()
  local r = {}
  
  r.pos     = gb.point.new(0,0)
  r.cells   = gb.array2d(10,10)
  
  
  return r
end

---------------
-- functions --
---------------

pipes.board.getcell = function(b,x,y)
  return gb.a2get(b.cells,x,y)
end

pipes.board.setcell = function(b,x,y,v)
  gb.a2set(b,x,y,v)
end

pipes.board.setpos = function(b,x,y)
  gb.point.set(b.pos,x,y)
end
